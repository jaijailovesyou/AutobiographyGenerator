﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Saure_MachineProblem1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Collecting user input for the autobiography
            Console.WriteLine("\n                                                 Autobiography\n");
            Console.Write("Enter your full name: ");
            string fullName = Console.ReadLine();

            Console.Write("Enter your date of birth: ");
            string dateOfBirth = Console.ReadLine();

            Console.Write("Enter your place of birth: ");
            string placeOfBirth = Console.ReadLine();

            Console.Write("Enter your current residence: ");
            string currentResidence = Console.ReadLine();

            // Early Life
            Console.Write("Enter your family background: ");
            string familyBackground = Console.ReadLine();

            Console.Write("Enter your parents' names: ");
            string parentsNames = Console.ReadLine();

            Console.Write("Enter your parents' professions: ");
            string parentsProfessions = Console.ReadLine();

            Console.Write("Enter the number of siblings: ");
            string numberOfSiblings = Console.ReadLine();

            Console.Write("Enter the names of your siblings: ");
            string siblingNames = Console.ReadLine();

            Console.Write("Enter your childhood hometown or area: ");
            string childhoodHometown = Console.ReadLine();

            Console.Write("Enter one or two childhood memories: ");
            string childhoodMemories = Console.ReadLine();

            // Education
            Console.Write("Enter your elementary school: ");
            string elementarySchool = Console.ReadLine();

            Console.Write("Enter any notable activities or achievements in elementary school: ");
            string notableActivities = Console.ReadLine();

            Console.Write("Enter your high school: ");
            string highSchool = Console.ReadLine();

            Console.Write("Enter high school activities or sports you participated in: ");
            string highSchoolActivities = Console.ReadLine();

            Console.Write("Enter your college major: ");
            string collegeMajor = Console.ReadLine();

            Console.Write("Enter your college or university: ");
            string collegeOrUniversity = Console.ReadLine();

            Console.Write("Enter your graduation year: ");
            string graduationYear = Console.ReadLine();

            // Achievements
            Console.Write("Enter your field of expertise: ");
            string field = Console.ReadLine();

            Console.Write("Enter any notable awards or recognitions: ");
            string awards = Console.ReadLine();

            Console.Write("Describe a personal milestone: ");
            string personalMilestone = Console.ReadLine();

            // Current Status in Class
            Console.Write("Is what you expect in the Programming 1 class happening? If yes, explain. If not, tell me the reason: ");
            string currentStatusInClass = Console.ReadLine();

            // Generating the autobiography using string interpolation
            Console.WriteLine($"\nAutobiography:\n");
            Console.WriteLine($"I am {fullName}, born on {dateOfBirth} in {placeOfBirth}. Currently, I reside in {currentResidence}, where I have embarked on a journey to document the chapters of my life.");
            Console.WriteLine($"\nEarly Life:");
            Console.WriteLine($"My roots trace back to {familyBackground}. My parents, {parentsNames}, both dedicated themselves to {parentsProfessions}, and I grew up alongside {numberOfSiblings} siblings, including {siblingNames}. The backdrop of my childhood was {childhoodHometown}, where I cultivated cherished memories of {childhoodMemories}.");
            Console.WriteLine($"\nEducation:");
            Console.WriteLine($"My educational journey commenced at {elementarySchool}, where I made a name for myself in {notableActivities}. Later, I graduated from {highSchool}, where I actively participated in {highSchoolActivities}. Following high school, I pursued a Bachelor's degree in {collegeMajor} at {collegeOrUniversity}, culminating in my graduation in {graduationYear}.");
            Console.WriteLine($"\nAchievements:");
            Console.WriteLine($"In the realm of {field}, I have been honored with multiple awards, including {awards}. However, one of the most memorable chapters of my life unfolded when I achieved {personalMilestone}.");
            Console.WriteLine($"\nCurrent Status in Class:");
            Console.WriteLine($"{currentStatusInClass}");

            Console.ReadLine();
            Console.ReadKey();
        }
    }
}
